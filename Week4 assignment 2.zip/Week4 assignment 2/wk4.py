import shutil
with open("students.txt", "w") as outfile:
    for x in range(3):
        ID = input("What is the student's ID number: ")
        outfile.write(ID + ", ")
        FirstName = input("What is the Student's first name: ")
        outfile.write(FirstName + ", ")
        LastName = input("What is the Student's last name: ")
        outfile.write(LastName + "\n")
        

    outfile.close()
    print("File has been created")

with open("students.bin", "wb") as outfile2:
    shutil.copyfile('students.txt','students.bin')
    print("File copy is done")
    outfile2.close()
