with open("DU.txt", "w") as outfile:
    outfile.write("DDDD  U   U" + "\n")
    outfile.write("D   D U   U" + "\n")
    outfile.write("D   D U   U" + "\n")
    outfile.write("DDDD   UUU" + "\n")


    outfile.close()

    file = open("DU.txt", "r")
    print(file.read())
